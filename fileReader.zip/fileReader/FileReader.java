import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class FileReader {

    public void filerReaderTask(String fileUrl) {
        java.io.FileReader fileReader=null;
        BufferedReader bufferedReader=null;
        File file = new File("./", fileUrl);

        try {
            fileReader = new java.io.FileReader(file);
            bufferedReader = new BufferedReader(fileReader);

            List<String> listOfLines = new ArrayList<>();
            String line;
            while((line = bufferedReader.readLine()) != null) {
                line = line.trim();
                listOfLines.add(line);
            }
            createJavaClass(listOfLines);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                if (fileReader != null)
                    fileReader.close();
                if (bufferedReader != null)
                    bufferedReader.close();
            }
            catch(Exception ex) {
                System.out.println("Exception While Closing Object");
            }
        }
    }

    private void createJavaClass(List<String> listOfLines) {
        String className = "RootClass.java";
        boolean append = false;
        try {
            FileWriter fileWriter = new FileWriter(className, append);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // check valid JSON
            if(!checkJsonValidation(listOfLines)) {
                throw new RuntimeException("Wrong JSON");
            }
            System.out.println("JSON is Correct");
//            for(String str : listOfLines) {
//
//            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkJsonValidation(List<String> list) {

        Stack<Character> stack = new Stack<>();

        StringBuilder sb = new StringBuilder();
        for(String temp : list) {
            int n = temp.length();
            for(int i=0; i<n; i++) {
                // Checking Brackets
                char ch = temp.charAt(i);
                sb.append(ch);
                if(ch == '{' || ch == '[' || ch == '"' || ch == 39) {
                    // Checking for "" & ''
                    if(!stack.isEmpty() && ch == '"' && stack.peek() == '"') {
                        stack.pop();
                    }
                    else if(!stack.isEmpty() && ch == 39 && stack.peek() == 39) {
                        stack.pop();
                    }
                    else
                        stack.push(ch);
                }
                else {
                    if((stack.peek() == '{' && ch == '}')
                            || (stack.peek() == '[' && ch == ']')) {
                        stack.pop();
                    }
                }
            }

        }

        if(!stack.isEmpty()) {
            return false;
        }

        if(sb.charAt(sb.length()-2) == ',') {
            throw new RuntimeException("Wrong JSON");
        }

        return true;
    }

    public static void main(String[] args) {
        String path = "Object.txt";

        FileReader fileReader = new FileReader();

        fileReader.filerReaderTask(path);
    }

}
